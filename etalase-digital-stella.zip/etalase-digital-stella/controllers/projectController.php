<?php
class ProjectController
{
    // [Read] Etalase - semua role
    public static function index(): void
    {
        $q = trim($_GET['q'] ?? '');
        $sql = 'SELECT p.*, u.nama AS pemilik FROM projects p JOIN users u ON u.id = p.user_id';
        $params = [];
        if ($q !== '') {
            $sql .= ' WHERE p.nama_project LIKE ? OR u.nama LIKE ?';
            $params = ["%$q%", "%$q%"];
        }
        $sql .= ' ORDER BY p.created_at DESC, p.id DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);

        view('projects/index', ['title' => 'Etalase Digital', 'projects' => $stmt->fetchAll(), 'q' => $q]);
    }

    // [Read] Detail satu karya - semua role
    public static function show($id): void
    {
        $stmt = db()->prepare('SELECT p.*, u.nama AS pemilik FROM projects p JOIN users u ON u.id = p.user_id WHERE p.id = ?');
        $stmt->execute([$id]);
        $project = $stmt->fetch();
        if (!$project) abort(404);

        view('projects/show', ['title' => $project['nama_project'], 'project' => $project]);
    }

    public static function showCreate(): void
    {
        view('projects/form', ['title' => 'Tambah Karya', 'project' => null]);
    }

    // [Create] - semua role
    public static function create(): void
    {
        $nama = trim($_POST['nama_project'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $link = trim($_POST['link_project'] ?? '');

        if ($nama === '') { flash('error', 'Nama project wajib diisi.'); redirect('/projects/new'); }
        if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
            flash('error', 'Link project harus berupa URL yang valid.'); redirect('/projects/new');
        }

        [$gambar, $err] = upload_gambar($_FILES['gambar'] ?? [], true);
        if ($err) { flash('error', $err); redirect('/projects/new'); }

        db()->prepare('INSERT INTO projects (user_id, nama_project, deskripsi, gambar, link_project) VALUES (?,?,?,?,?)')
            ->execute([auth_user()['id'], $nama, $deskripsi, $gambar, $link]);

        flash('success', 'Karya berhasil ditambahkan.');
        redirect('/projects');
    }

    // Ambil project + cek hak akses (owner / admin / super admin)
    private static function ambil($id): array
    {
        $stmt = db()->prepare('SELECT * FROM projects WHERE id = ?');
        $stmt->execute([$id]);
        $project = $stmt->fetch();
        if (!$project) abort(404);
        if (!can_modify(auth_user(), $project)) abort(403);
        return $project;
    }

    public static function showEdit($id): void
    {
        view('projects/form', ['title' => 'Edit Karya', 'project' => self::ambil($id)]);
    }

    // [Update]
    public static function update($id): void
    {
        $project = self::ambil($id);
        $nama = trim($_POST['nama_project'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $link = trim($_POST['link_project'] ?? '');
        $back = '/projects/' . (int) $id . '/edit';

        if ($nama === '') { flash('error', 'Nama project wajib diisi.'); redirect($back); }
        if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
            flash('error', 'Link project harus berupa URL yang valid.'); redirect($back);
        }

        [$gambarBaru, $err] = upload_gambar($_FILES['gambar'] ?? [], false);
        if ($err) { flash('error', $err); redirect($back); }

        $gambar = $project['gambar'];
        if ($gambarBaru) { hapus_file($project['gambar']); $gambar = $gambarBaru; }

        db()->prepare('UPDATE projects SET nama_project=?, deskripsi=?, gambar=?, link_project=? WHERE id=?')
            ->execute([$nama, $deskripsi, $gambar, $link, $project['id']]);

        flash('success', 'Karya berhasil diperbarui.');
        redirect('/projects');
    }

    // [Delete]
    public static function destroy($id): void
    {
        $project = self::ambil($id);
        db()->prepare('DELETE FROM projects WHERE id = ?')->execute([$project['id']]);
        hapus_file($project['gambar']);
        flash('success', 'Karya berhasil dihapus.');
        redirect('/projects');
    }

    // Hapus semua karya - Admin & Super Admin saja
    public static function deleteAll(): void
    {
        $rows = db()->query('SELECT gambar FROM projects')->fetchAll();
        db()->exec('DELETE FROM projects');
        foreach ($rows as $r) hapus_file($r['gambar']);
        flash('success', 'Semua karya berhasil dihapus.');
        redirect('/projects');
    }
}
