<?php require __DIR__ . '/../partials/header.php'; ?>
<?php
$total = count($projects);
$pemilik = count(array_unique(array_column($projects, 'pemilik')));
?>
<section class="hero" id="hero">
  <?= constellation() ?>
  <div class="hero-copy">
    <h1>Etalase Digital</h1>
    <p class="lead">Kumpulan karya digital siswa Stella. Cari, lihat, dan buka langsung proyeknya.</p>
    <form action="<?= url('/projects') ?>" method="GET" class="hero-search" role="search">
      <?= icon('search') ?>
      <label for="q" class="sr-only">Cari karya atau pemilik</label>
      <input type="text" id="q" name="q" value="<?= e($q) ?>" placeholder="Cari karya / pemilik..." autocomplete="off" data-live-filter>
      <button class="btn">Cari</button>
    </form>
  </div>
</section>

<div class="section-head">
  <div>
    <h2><?= $q !== '' ? 'Hasil untuk “' . e($q) . '”' : 'Semua karya' ?></h2>
    <p class="count" id="count" data-total="<?= $total ?>"><?= $total ?> karya dari <?= $pemilik ?> pemilik</p>
  </div>
  <div class="toolbar-actions">
    <a href="<?= url('/projects/new') ?>" class="btn btn-primary"><?= icon('plus') ?>Tambah Karya</a>
    <?php if ($user['role'] !== 'siswa' && $total): ?>
      <form action="<?= url('/admin/projects/delete-all') ?>" method="POST" class="inline"
            onsubmit="return confirm('Hapus SEMUA karya? Tindakan ini tidak bisa dibatalkan!')"
            data-confirm="Semua karya akan dihapus permanen dan tidak bisa dikembalikan."
            data-confirm-title="Hapus semua karya?" data-confirm-yes="Ya, hapus semua">
        <?= csrf_field() ?>
        <button class="btn btn-danger"><?= icon('trash') ?>Hapus Semua</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php if (!$total): ?>
  <div class="card empty">
    <svg class="empty-art" viewBox="0 0 132 100" fill="none" aria-hidden="true">
      <path d="M18 74 46 44l30 22 38-40" stroke="currentColor" stroke-opacity=".35" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="4 6"/>
      <circle cx="18" cy="74" r="5" fill="currentColor" fill-opacity=".5"/><circle cx="46" cy="44" r="6" fill="currentColor" fill-opacity=".7"/>
      <circle cx="76" cy="66" r="5" fill="currentColor" fill-opacity=".5"/><circle cx="114" cy="26" r="9" fill="#E32636"/>
    </svg>
    <?php if ($q !== ''): ?>
      <h2>Tidak ada karya yang cocok</h2>
      <p>Coba kata kunci lain, atau tampilkan semua karya.</p>
      <a href="<?= url('/projects') ?>" class="btn">Tampilkan semua karya</a>
    <?php else: ?>
      <h2>Belum ada karya digital</h2>
      <p>Jadilah yang pertama menambahkan!</p>
      <a href="<?= url('/projects/new') ?>" class="btn btn-primary"><?= icon('plus') ?>Tambah karya pertama</a>
    <?php endif; ?>
  </div>
<?php endif; ?>

<div class="card empty no-result" id="no-result">
  <h2>Tidak ada karya yang cocok</h2>
  <p>Coba kata kunci lain.</p>
</div>

<div class="grid" id="grid">
<?php foreach ($projects as $i => $p): ?>
  <article class="card project reveal" style="--d:<?= min($i, 8) * 70 ?>ms" data-search="<?= e(mb_strtolower($p['nama_project'] . ' ' . $p['pemilik'] . ' ' . $p['deskripsi'])) ?>">
    <div class="thumb">
      <img src="<?= url('uploads/' . rawurlencode($p['gambar'])) ?>" alt="<?= e($p['nama_project']) ?>" loading="lazy">
    </div>
    <div class="body">
      <h3><a href="<?= url('/projects/' . (int) $p['id']) ?>"><?= e($p['nama_project']) ?></a></h3>
      <div class="owner">
        <?= avatar($p['pemilik'], 'avatar-sm') ?>
        <span>oleh <strong><?= e($p['pemilik']) ?></strong></span>
        <time datetime="<?= e(date('Y-m-d', strtotime($p['created_at']))) ?>"><?= e(tgl_id($p['created_at'])) ?></time>
      </div>
      <p class="desc"><?= nl2br(e($p['deskripsi'])) ?></p>
      <div class="actions">
        <?php if (!empty($p['link_project'])): ?>
          <a class="btn btn-sm" href="<?= e($p['link_project']) ?>" target="_blank" rel="noopener">Buka Link <?= icon('link') ?></a>
        <?php endif; ?>
        <?php if (can_modify($user, $p)): ?>
          <a class="btn btn-sm" href="<?= url('/projects/' . (int) $p['id'] . '/edit') ?>">Edit</a>
          <form action="<?= url('/projects/' . (int) $p['id']) ?>" method="POST" class="inline"
                onsubmit="return confirm('Hapus karya ini?')"
                data-confirm="“<?= e($p['nama_project']) ?>” akan dihapus permanen." data-confirm-title="Hapus karya ini?" data-confirm-yes="Ya, hapus">
            <?= csrf_field() ?><?= method_field('DELETE') ?>
            <button class="btn btn-sm btn-danger">Hapus</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </article>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
