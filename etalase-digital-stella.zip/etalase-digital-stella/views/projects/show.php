<?php require __DIR__ . '/../partials/header.php'; ?>
<?php $gambarUrl = url('uploads/' . rawurlencode($project['gambar'])); ?>
<div class="detail">
  <a class="back" href="<?= url('/projects') ?>"><?= icon('back') ?>Kembali ke Etalase</a>

  <section class="detail-media" style="--bg:url('<?= e($gambarUrl) ?>')">
    <button type="button" class="detail-img" data-lightbox="<?= e($gambarUrl) ?>" data-caption="<?= e($project['nama_project']) ?>" aria-label="Perbesar gambar <?= e($project['nama_project']) ?>">
      <img src="<?= e($gambarUrl) ?>" alt="<?= e($project['nama_project']) ?>">
    </button>
    <span class="detail-hint">Klik gambar untuk memperbesar</span>
  </section>

  <article class="card detail-body">
    <h1><?= e($project['nama_project']) ?></h1>

    <div class="meta">
      <div class="meta-item">
        <?= avatar($project['pemilik']) ?>
        <div><span class="lbl">Dibuat oleh</span><span class="val"><?= e($project['pemilik']) ?></span></div>
      </div>
      <div class="meta-item">
        <span class="meta-ic"><?= icon('calendar') ?></span>
        <div><span class="lbl">Dibuat pada</span><time class="val" datetime="<?= e(date('c', strtotime($project['created_at']))) ?>"><?= e(tgl_lengkap($project['created_at'])) ?></time></div>
      </div>
    </div>

    <h2>Deskripsi</h2>
    <?php if (trim((string) $project['deskripsi']) !== ''): ?>
      <p class="detail-desc"><?= nl2br(e($project['deskripsi'])) ?></p>
    <?php else: ?>
      <p class="detail-desc muted">Belum ada deskripsi untuk karya ini.</p>
    <?php endif; ?>

    <div class="actions">
      <?php if (!empty($project['link_project'])): ?>
        <a class="btn btn-primary" href="<?= e($project['link_project']) ?>" target="_blank" rel="noopener">Buka Link <?= icon('link') ?></a>
      <?php endif; ?>
      <?php if (can_modify($user, $project)): ?>
        <a class="btn" href="<?= url('/projects/' . (int) $project['id'] . '/edit') ?>"><?= icon('edit') ?>Edit</a>
        <form action="<?= url('/projects/' . (int) $project['id']) ?>" method="POST" class="inline"
              onsubmit="return confirm('Hapus karya ini?')"
              data-confirm="“<?= e($project['nama_project']) ?>” akan dihapus permanen." data-confirm-title="Hapus karya ini?" data-confirm-yes="Ya, hapus">
          <?= csrf_field() ?><?= method_field('DELETE') ?>
          <button class="btn btn-danger"><?= icon('trash') ?>Hapus</button>
        </form>
      <?php endif; ?>
    </div>
  </article>
</div>
<?php require __DIR__ . '/../partials/footer.php'; ?>
